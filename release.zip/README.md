![Minecraft version](https://img.shields.io/badge/version-1.16.4-blue.svg)
![GitHub stars](https://img.shields.io/github/stars/TUSB/TheUnusualResourcePack.svg?style=social)
![Twitter Follow](https://img.shields.io/twitter/follow/TUSkyBlock.svg?style=social)


# TheUnusualResourcePack v13
Minecraft 配布ワールド 「The Unusual SkyBlock」次期開発用リソースパックリポジトリ

公式サイト: https://skyblock.jp/
